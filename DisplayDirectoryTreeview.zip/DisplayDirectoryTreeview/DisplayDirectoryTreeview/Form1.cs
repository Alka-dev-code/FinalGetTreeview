﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using HtmlAgilityPack;

namespace DisplayDirectoryTreeview
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void btnDirectoryPath_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.SelectedPath = txtDirectoryPath.Text;
            DialogResult drResult = folderBrowserDialog1.ShowDialog();
            if (drResult == System.Windows.Forms.DialogResult.OK)
                txtDirectoryPath.Text = folderBrowserDialog1.SelectedPath;
        }

        List<string> dataSource = new List<string>();
        List<string> imgDataSource = new List<string>();
        private void btnLoadDirectory_Click(object sender, EventArgs e)
        {
            SetImageSrc();
            SetDataSource();
            // Setting Inital Value of Progress Bar
            progressBar1.Value = 0;
            // Clear All Nodes if Already Exists
            treeView1.Nodes.Clear();
            toolTip1.ShowAlways = true;
            if (txtDirectoryPath.Text != "" && Directory.Exists(txtDirectoryPath.Text))
                LoadDirectory(txtDirectoryPath.Text);
            
            else
                MessageBox.Show("Select Directory!!");
        }

        public void LoadDirectory(string Dir)
        {
            DirectoryInfo di = new DirectoryInfo(Dir);
            //Setting ProgressBar Maximum Value
            progressBar1.Maximum = Directory.GetFiles(Dir, "*.*", SearchOption.AllDirectories).Length + Directory.GetDirectories(Dir, "**", SearchOption.AllDirectories).Length;
            treeView1.CheckBoxes = true;
            TreeNode tds = treeView1.Nodes.Add(di.Name);
            tds.Tag = di.FullName;
           
            tds.StateImageIndex = 0;           
            LoadFiles(Dir, tds);
            LoadSubDirectories(Dir, tds);
        }

        private void LoadSubDirectories(string dir, TreeNode td)
        {
            
            // Get all subdirectories
            string[] subdirectoryEntries = Directory.GetDirectories(dir);
            // Loop through them to see if they have any other subdirectories
            foreach (string subdirectory in subdirectoryEntries)
            {
             
                DirectoryInfo di = new DirectoryInfo(subdirectory);
                TreeNode tds = td.Nodes.Add(di.Name);

                List<string> selectedSource = new List<string>();
                selectedSource = dataSource.Where(x => x == di.Name).ToList();
               // List<string> selectedImgSource = new List<string>();
                                
               
                if (td.Parent == null && selectedSource.Count > 0)
                {
                    tds.Checked = true;
                }   
                
                if(imgDataSource.Any(x => x == di.Name))
                {
                    tds.Checked = true;
                }            

                tds.StateImageIndex = 0;
                tds.Tag = di.FullName;
                LoadFiles(subdirectory, tds);
                LoadSubDirectories(subdirectory, tds);
                UpdateProgress();

            }
        }

        private void LoadFiles(string dir, TreeNode td)
        {
            string[] Files = Directory.GetFiles(dir, "*.*");

            // Loop through them to see files
            foreach (string file in Files)
            {
                FileInfo fi = new FileInfo(file);
                TreeNode tds = td.Nodes.Add(fi.Name);

                if (imgDataSource.Any(x => x == fi.Name))
                {
                    tds.Checked = true;
                }

                tds.Tag = fi.FullName;
                tds.StateImageIndex = 1;
                UpdateProgress();

            }
        }

        private void UpdateProgress()
        {
            if (progressBar1.Value < progressBar1.Maximum)
            {
                progressBar1.Value++;
                int percent = (int)(((double)progressBar1.Value / (double)progressBar1.Maximum) * 100);
                progressBar1.CreateGraphics().DrawString(percent.ToString() + "%", new Font("Arial", (float)8.25, FontStyle.Regular), Brushes.Black, new PointF(progressBar1.Width / 2 - 10, progressBar1.Height / 2 - 7));

                Application.DoEvents();
            }
        }

        private void treeView1_MouseMove(object sender, MouseEventArgs e)
        {
            // Get the node at the current mouse pointer location.
            TreeNode theNode = this.treeView1.GetNodeAt(e.X, e.Y);

            // Set a ToolTip only if the mouse pointer is actually paused on a node.
            if (theNode != null && theNode.Tag != null)
            {
                // Change the ToolTip only if the pointer moved to a new node.
                if (theNode.Tag.ToString() != this.toolTip1.GetToolTip(this.treeView1))
                    this.toolTip1.SetToolTip(this.treeView1, theNode.Tag.ToString());

            }
            else     // Pointer is not over a node so clear the ToolTip.
            {
                this.toolTip1.SetToolTip(this.treeView1, "");
            }
        }

        // Updates all child tree nodes recursively.
        private void CheckAllChildNodes(TreeNode treeNode, bool nodeChecked)
        {
            foreach (TreeNode node in treeNode.Nodes)
            {
                node.Checked = nodeChecked;
                if (node.Nodes.Count > 0)
                {
                    // If the current node has child nodes, call the CheckAllChildsNodes method recursively.
                    this.CheckAllChildNodes(node, nodeChecked);
                }
            }
        }

        // NOTE   This code can be added to the BeforeCheck event handler instead of the AfterCheck event.
        // After a tree node's Checked property is changed, all its child nodes are updated to the same value.
        private void treeView1_AfterCheck(object sender, TreeViewEventArgs e)
        {
            // The code only executes if the user caused the checked state to change.
            if (e.Action != TreeViewAction.Unknown)
            {
                if (e.Node.Nodes.Count > 0)
                {
                    /* Calls the CheckAllChildNodes method, passing in the current 
                    Checked value of the TreeNode whose checked state changed. */
                    this.CheckAllChildNodes(e.Node, e.Node.Checked);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string folderPath = txtDirectoryPath.Text + "/" + "publish_" + Guid.NewGuid().ToString() + "/" + treeView1.TopNode.FullPath;
            if (!System.IO.Directory.Exists(folderPath))
            {
                System.IO.Directory.CreateDirectory(folderPath);
            }

            List<TreeNode> checked_nodes = new List<TreeNode>();
            FindCheckedNodes(checked_nodes, treeView1.Nodes);
           
            foreach (TreeNode item in checked_nodes)
            {
                if(!item.Text.Contains("."))
                {
                    string insideFolder = folderPath + "/" + item.Text;
                    if (!System.IO.Directory.Exists(insideFolder))
                    {
                        System.IO.Directory.CreateDirectory(insideFolder);                       
                    }
                    //System.IO.File.Move(item.Tag.ToString(), insideFolder, true);

                    //Now Create all of the directories
                    foreach (string dirPath in Directory.GetDirectories(item.Tag.ToString(), "*",
                        SearchOption.AllDirectories))
                        Directory.CreateDirectory(dirPath.Replace(item.Tag.ToString(), insideFolder));

                    //Copy all the files & Replaces any files with the same name
                    foreach (string newPath in Directory.GetFiles(item.Tag.ToString(), "*.*",
                        SearchOption.AllDirectories))
                        File.Copy(newPath, newPath.Replace(item.Tag.ToString(), insideFolder), true);
                }
                else                    
                {
                    string insideFolder = folderPath + "/" + item.FullPath.Replace(treeView1.TopNode.FullPath, "");
                   if (!System.IO.Directory.Exists(insideFolder.Replace(item.Text,"")))
                    {
                        System.IO.Directory.CreateDirectory(insideFolder.Replace(item.Text, ""));
                    }

                    System.IO.File.Copy(item.Tag.ToString(), insideFolder, true);

                }
            }
        }

        // Return a list of the TreeNodes that are checked.
        private void FindCheckedNodes(
            List<TreeNode> checked_nodes, TreeNodeCollection nodes)
        {
            foreach (TreeNode node in nodes)
            {
                // Add this node.
                if (node.Checked) checked_nodes.Add(node);

                // Check the node's descendants.
                FindCheckedNodes(checked_nodes, node.Nodes);
            }
        }

        public void SetImageSrc()
        {

            HtmlAgilityPack.HtmlDocument document = new HtmlAgilityPack.HtmlDocument();
            document.Load(txtWebsite.Text.Trim());

            HashSet<string> lstImageName = new HashSet<string>();
            string imgNamee = string.Empty;

            foreach (HtmlNode node in document.DocumentNode
                                   .SelectNodes("//img"))
            {

                if (node.Attributes["src"].Value != null)
                {
                    if (node.Attributes["src"].Value.Contains("?"))
                    {
                        string[] src = node.Attributes["src"].Value.Split('?');
                        imgNamee = Path.GetFileName(src[0]);
                    }
                    else
                    {
                        string src = node.Attributes["src"].Value;
                        imgNamee = Path.GetFileName(src);
                    }
                }

                if (!string.IsNullOrEmpty(imgNamee))
                {
                    lstImageName.Add(imgNamee);
                }
            }
            imgDataSource = lstImageName.ToList();
        }

        public void SetDataSource()
        {   
            List<WebPartEntity> lstwebPartEntities = new List<WebPartEntity>();

            //Load a Page from a Saved Document
            HtmlAgilityPack.HtmlDocument document = new HtmlAgilityPack.HtmlDocument();
            document.Load(txtWebsite.Text.Trim());

            //select table with row in from Saved Document               
            foreach (HtmlNode row in document.DocumentNode.SelectNodes("//table[@class='ms-vb']/tr"))
            {
                //select row attributes
                HtmlAttributeCollection htmlAttributes = row.Attributes;

                if (htmlAttributes != null && htmlAttributes.Count > 0 && htmlAttributes[0].Name == "webpartrow" && htmlAttributes[0].Value == "1")
                {
                    HtmlNodeCollection cells = row.SelectNodes("td");

                    WebPartEntity webPartEntity = new WebPartEntity();
                    webPartEntity.WebPartTitle = cells[0].InnerText;
                    webPartEntity.Type = cells[1].InnerText;
                    webPartEntity.IsOpenOnPage = cells[2].InnerText == "Yes";
                    imgDataSource.Add(cells[0].InnerText);
                    //lstwebPartEntities.Add(webPartEntity);
                }
            }
            //return View();
        }
    }
}
